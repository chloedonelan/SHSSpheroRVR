// SpheroRVR - Version: Latest
#include <SpheroRVR.h>

class LedControls
{
  private:
    // led groups for the headlights
    uint32_t ledGroupR, ledGroupL;
    // constants for turning array values "on" and "off"
    const uint8_t on = 0xFF, off = 0x00;
    // the array for the left headlight
    uint8_t leftArray[3] = {off, off, off};
    // the array for the right headlight
    uint8_t rightArray[3] = {off, off, off};

    void setRight()
    {
      // sets the right headlight to its new color
      rvr.setAllLeds(ledGroupR, rightArray, sizeof(rightArray) / sizeof(rightArray[0]));
    }
    
    void setLeft()
    {
      // sets the left headlight to its new color
      rvr.setAllLeds(ledGroupL, leftArray, sizeof(leftArray) / sizeof(leftArray[0]));
    }
    
    void setBoth()
    {
      // sets both headlights to their new color
      setLeft();
      setRight();
    }

    resetRight()
    {
      // resets rightArray back to default
      for (int i = 0; i < 3; i++)
        rightArray[i] = off;
    }
    
    resetLeft()
    {
      // resets leftArray back to default
      for (int i = 0; i < 3; i++)
        leftArray[i] = off;
    }
    
    void resetBoth()
    {
      // resets leftArray and rightArray back to default
      resetLeft();
      resetRight();
    }
  
  public:
    // constants for the different array indexes and what they correspond to
    const int none = -1, red = 0, green = 1, blue = 2, yellow = 3, purple = 4;
    
    void setup()
    {
      // sets up the led group for the right headlight
      ledGroupR = 0;
      ledGroupR |= (1 << static_cast<uint8_t>(LEDs::rightHeadlightRed));
      ledGroupR |= (1 << static_cast<uint8_t>(LEDs::rightHeadlightGreen));
      ledGroupR |= (1 << static_cast<uint8_t>(LEDs::rightHeadlightBlue));
      
      // sets up the led group for the left headlight
      ledGroupL = 0;
      ledGroupL |= (1 << static_cast<uint8_t>(LEDs::leftHeadlightRed));
      ledGroupL |= (1 << static_cast<uint8_t>(LEDs::leftHeadlightGreen));
      ledGroupL |= (1 << static_cast<uint8_t>(LEDs::leftHeadlightBlue));
    }
    
    void bothHeadlights(int color)
    {
      resetBoth();
      
      // sets both headlights to the specified color (-1 = none, 0 = red, 1 = green, 2 = blue, 3 = yellow, 4 = purple) 
      switch (color){
        case 0:
          // sets headlights to red
          leftArray[red] = on;
          rightArray[red] = on;
          break;
        case 1:
          // sets headlights to green
          leftArray[green] = on;
          rightArray[green] = on;
          break;
        case 2:
          // sets headlights to blue
          leftArray[blue] = on;
          rightArray[blue] = on;
          break;
        case 3:
          // sets headlights to yellow
          leftArray[red] = on;
          rightArray[red] = on;
          leftArray[green] = on;
          rightArray[green] = on;
          break;
        case 4:
          // sets the headlights to purple
          leftArray[red] = on;
          rightArray[red] = on;
          leftArray[blue] = on;
          rightArray[blue] = on;
          break;
      }
      setBoth();
    }

    void rightHeadlight(int color)
    {
      resetRight();
        
      // sets the right headlight to the specified color (-1 = none, 0 = red, 1 = green, 2 = blue, 3 = yellow, 4 = purple)
      switch (color){
        case 0:
          // sets right headlight to red
          rightArray[red] = on;
          break;
        case 1:
          // sets right headlight to green
          rightArray[green] = on;
          break;
        case 2:
          // sets right headlight to blue
          rightArray[blue] = on;
          break;
        case 3:
          // sets right headlight to yellow
          rightArray[red] = on;
          rightArray[green] = on;
          break;
        case 4:
          // sets the right headlight to purple
          rightArray[red] = on;
          rightArray[blue] = on;
          break;
      }
      setRight();
    }

    void leftHeadlight(int color)
    {
      resetLeft();
        
      // sets the left headlight to the specified color (-1 = none, 0 = red, 1 = green, 2 = blue, 3 = yellow, 4 = purple)
      switch (color){
        case 0:
          // sets left headlight to red
          leftArray[red] = on;
          break;
        case 1:
          // sets left headlight to green
          leftArray[green] = on;
          break;
        case 2:
          // sets left headlight to blue
          leftArray[blue] = on;
          break;
        case 3:
          // sets left headlight to yellow
          leftArray[red] = on;
          leftArray[green] = on;
          break;
        case 4:
          // sets the left headlight to purple
          leftArray[red] = on;
          leftArray[blue] = on;
          break;
      }
      setLeft();
    }
};