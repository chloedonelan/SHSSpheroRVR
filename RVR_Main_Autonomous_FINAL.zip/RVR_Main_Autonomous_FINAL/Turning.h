// SpheroRVR - Version: Latest 
#include <SpheroRVR.h>
#include "LedControls.h"

LedControls lights;

class Turning : public LedControls
{
  public:
    void setup()
    {
      // setting up the led group for both headlights
      lights.setup();
    }
    
    void turnRight()
    {
      // turns right 90 degrees
      // turns the right headlight yellow and the left headlight off
      lights.rightHeadlight(lights.yellow);
      lights.leftHeadlight(lights.none);
      rvr.driveWithHeading(0, 90, static_cast<uint8_t>(DriveFlags::none));
      delay(1000);
      rvr.resetYaw();
    }

    void turnLeft()
    {
      // turns left 90 degrees
      // turns the left headlight yellow and the right headlight off
      lights.leftHeadlight(lights.yellow);
      lights.rightHeadlight(lights.none);
      rvr.driveWithHeading(0, 270, static_cast<uint8_t>(DriveFlags::none));
      delay(1000);
      rvr.resetYaw();
    }

    void turn180()
    {
      // turns around 180 degrees
      // turns both headlights yellow
      lights.bothHeadlights(lights.yellow);
      rvr.driveWithHeading(0, 180, static_cast<uint8_t>(DriveFlags::none));
      delay(1500);
      rvr.resetYaw();
    }

    void turnLeft(int deg)
    {
      // turns left by a specific degree
      // turns the left headlight yellow and the right headlight off
      lights.leftHeadlight(lights.yellow);
      lights.rightHeadlight(lights.none);
      rvr.driveWithHeading(0, 360-deg, static_cast<uint8_t>(DriveFlags::none));
      delay(1000);
      rvr.resetYaw();
    }
 
    void turnRight(int deg)
    {
      // turns right by a specific degree
      // turns the right headlight yellow and the left headlight off
      lights.rightHeadlight(lights.yellow);
      lights.leftHeadlight(lights.none);
      rvr.driveWithHeading(0, deg, static_cast<uint8_t>(DriveFlags::none));
      delay(1000);
      rvr.resetYaw();
    }
};