// SpheroRVR - Version: Latest 
#include <SpheroRVR.h>
#include <NewPing.h>
#include "Turning.h"

float duration, distance;
const int trigPinL = 4;
const int echoPinL = 5;
const int trigPinM = A1;
const int echoPinM = A2;
const int trigPinR = 7;
const int echoPinR = 8;

Turning turner;

#define SONAR_NUM 3
#define MAX_DISTANCE 100

//this creates an array of sensors
NewPing sonar[SONAR_NUM] = {  
  NewPing(trigPinL, echoPinL, MAX_DISTANCE),
  NewPing(trigPinM, echoPinM, MAX_DISTANCE), 
  NewPing(trigPinR, echoPinR, MAX_DISTANCE)
};

class Movement : public Turning
{
  public:
    void setup()
    {
      pinMode(trigPinL, OUTPUT);
      pinMode(echoPinL, INPUT);
      pinMode(trigPinM, OUTPUT);
      pinMode(echoPinM, INPUT);
      pinMode(trigPinR, OUTPUT);
      pinMode(echoPinR, INPUT);
      Serial.begin(9600);
      rvr.configUART(&Serial);
      turner.setup();
    }
    
    /*int scan()
    {
      digitalWrite(trigPin, LOW);
      delayMicroseconds(2);
      digitalWrite(trigPin, HIGH);
      delayMicroseconds(10);
      digitalWrite(trigPin, LOW);

      duration = pulseIn(echoPin, HIGH);
      distance = (duration*.0343)/2;
      Serial.print("Distance: ");
      Serial.println(distance);
      delay(1);
      return distance;
    }*/
    
    //scan function that incorporates all 3 ultrasonic sensors.
    //takes an integer parameter distance which is the distance at which
    //if there's an obstacle, the rvr should react
    //the return value is also an int, which tells which sensor detected the rvr
    int scan(int distance)
    {
      int leftVal = sonar[0].ping_cm();
      int centerVal = sonar[1].ping_cm();
      int rightVal = sonar[2].ping_cm();
      
      bool left = triggered(leftVal, distance);
      bool center = triggered(centerVal, distance);
      bool right = triggered(rightVal, distance);
      
      if(left || center || right)
      {
        if(left && center && right){
          return 6;
        }
        if (left){
          if(center){
            return 3;
          }else if(right){
            return 5;
          }else{
            return 0;
          }
        }else if(right){
          if(center){
            return 4;
          }else{
            return 2;
          }
        }else{
          return 1;
        }
      }
      return -1;
    }
    
    //the logic used for scan()
    //if the return distance from ping_cm() is within the distance threshold
    //and isn't 0 (out of range), it returns true; if not, it returns false
    //eliminates false positive readings
    bool triggered(int returnDist, int distThresh)
    {
      if(returnDist != 0 && returnDist <= distThresh)
        return true;
      return false;
    }

    void driveForward(int speed) 
    { 
      // turns the headlights green
      // drive forward w/ a speed of the value of parameter speed
      lights.bothHeadlights(lights.green);
      rvr.driveWithHeading(speed , 0, static_cast<uint8_t>(DriveFlags::none));
    }
    
    void driveForward(int speed, int ms)
    {
      // turns the headlights green
      // drive forward w/ a speed of the value of parameter speed
      // does so for the time of parameter ms
      lights.bothHeadlights(lights.green);
      rvr.driveWithHeading(speed , 0, static_cast<uint8_t>(DriveFlags::none));
      delay(ms);
    }

    void driveBackward(int speed, int ms)
    {
      // turns the headlights red
      // drives backward w/ a speed of the value of parameter speed
      // does so for the time of parameter ms
      lights.bothHeadlights(lights.red);
      rvr.driveWithHeading(speed , 0, static_cast<uint8_t>(DriveFlags::driveReverse));
      delay(ms);
    }
    
    void semCircleRight()
    {
      // the rvr moves in a semi circle going around to the right
      // turns the right headlight blue and left headlight off
      lights.rightHeadlight(lights.blue);
      lights.leftHeadlight(lights.none);
      turner.turnRight();
      rvr.rawMotors(RawMotorModes::forward, 50, RawMotorModes::forward, 100);
      delay(500);
    }

    void semCircleLeft()
    {
      // the rvr moves in a semi circle going around to the left
      // turns the left headlight blue and right headlight off
      lights.leftHeadlight(lights.blue);
      lights.rightHeadlight(lights.none);
      turner.turnLeft();
      rvr.rawMotors(RawMotorModes::forward, 100, RawMotorModes::forward, 50);
      delay(500);
    }
};