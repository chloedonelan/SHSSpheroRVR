// SpheroRVR - Version: Latest 
#include <SpheroRVR.h>
#include <NewPing.h>
#include "Turning.h"

float duration, distance;
const int trigPinL = 4;
const int echoPinL = 5;
const int trigPinM = A1;
const int echoPinM = A2;
const int trigPinR = 7;
const int echoPinR = 8;
int back = 200;
int cm = 15;
int close = 10;

Turning turner;

#define SONAR_NUM 3
#define MAX_DISTANCE 100

//this creates an array of sensors
NewPing sonar[SONAR_NUM] = {  
  NewPing(trigPinL, echoPinL, MAX_DISTANCE),
  NewPing(trigPinM, echoPinM, MAX_DISTANCE), 
  NewPing(trigPinR, echoPinR, MAX_DISTANCE)
};

class Movement : public Turning
{
  private:
    //the logic used for scan()
    //if the return distance from ping_cm() is within the distance threshold
    //and isn't 0 (out of range), it returns true; if not, it returns false
    //eliminates false positive readings
    bool triggered(int returnDist, int distThresh)
    {
      if(returnDist != 0 && returnDist <= distThresh)
        return true;
      return false;
    }
  
  public:
    void setup()
    {
      pinMode(trigPinL, OUTPUT);
      pinMode(echoPinL, INPUT);
      pinMode(trigPinM, OUTPUT);
      pinMode(echoPinM, INPUT);
      pinMode(trigPinR, OUTPUT);
      pinMode(echoPinR, INPUT);
      turner.setup();
    }
    
    //scan function that incorporates all 3 ultrasonic sensors.
    //takes an integer parameter distance which is the distance at which
    //if there's an obstacle, the rvr should react
    //the return value is also an int, which tells which sensor detected the rvr
    int scan(int distance)
    {
      int leftVal = sonar[0].ping_cm();
      int centerVal = sonar[1].ping_cm();
      int rightVal = sonar[2].ping_cm();
      
      bool left = triggered(leftVal, distance);
      bool center = triggered(centerVal, distance);
      bool right = triggered(rightVal, distance);
      
      if(left || center || right)
      {
        if(left && center && right){
          return 6;
        }
        if (left){
          if(center){
            return 3;
          }else if(right){
            return 5;
          }else{
            return 0;
          }
        }else if(right){
          if(center){
            return 4;
          }else{
            return 2;
          }
        }else{
          return 1;
        }
      }
      return -1;
    }

    void driveForward(int speed) 
    { 
      // turns the headlights green
      // drive forward w/ a speed of the value of parameter speed
      lights.bothHeadlights(lights.green);
      rvr.driveWithHeading(speed , 0, static_cast<uint8_t>(DriveFlags::none));
    }
    
    void driveForward(int speed, int ms)
    {
      // turns the headlights green
      // drive forward w/ a speed of the value of parameter speed
      // does so for the time of parameter ms
      lights.bothHeadlights(lights.green);
      rvr.driveWithHeading(speed , 0, static_cast<uint8_t>(DriveFlags::none));
      delay(ms);
    }

    void driveBackward(int speed, int ms)
    {
      // turns the headlights red
      // drives backward w/ a speed of the value of parameter speed
      // does so for the time of parameter ms
      lights.bothHeadlights(lights.red);
      rvr.driveWithHeading(speed , 0, static_cast<uint8_t>(DriveFlags::driveReverse));
      delay(ms);
    }
    
    //Attempts to locate a clear path at 4 points
    void findOut(int speed)
    {
      driveBackward(speed, back);
      turner.turnLeft();
      tooClose(speed);
      
      if(scan(cm) == 1 || scan(cm) == 3 || scan(cm) == 4 || scan(cm) == 6)
      {
        turn180();
        tooClose(speed);
        if(scan(cm) == 1 || scan(cm) == 3 || scan(cm) == 4 || scan(cm) == 6)
        {
          turner.turnRight();
          tooClose(speed);
        }
      }
    }
    
    //Attempts to locate a clear path at 360 points
    //Takes an boolean parameter direction to indicate which direction to turn in
    //Values: 0: left; 1: right
    void findOut360(bool direction, int speed, int deg)
    {
      bool clear = false;
      driveBackward(speed, back);
       
      while(!clear)
      {
        tooClose(speed);
        if(direction)
          turnRight(deg);
        else
          turnLeft(deg);
          
        if(scan(cm) == -1)
          clear = true;
      }
    }
    
    //function called to have RVR back up a bit extra
    //before turning in case it's too close to an object to
    //avoid hitting it while turning
    void tooClose(int speed)
    {
      if(scan(close) != -1)
          driveBackward(speed, back);
    }
    
    //Allows the RVR to avoid any obstacles in its path
    void avoidance(int speed, int timeMs, int deg)
    {
      int detected = scan(cm);
     
      switch(detected){
        case -1:
          //directs the RVR to drive forward as paths are clear
          driveForward(speed, timeMs);
        break;
        case 0:
          //directs the RVR to turn right as the left is blocked
          turner.turnRight(deg);
        break;
        case 1:
          //directs the RVR to execute findOut() as the front is blocked
          findOut(speed);
        break;
        case 2:
          //directs the RVR to turn left as the right is blocked
          turner.turnLeft(deg);
        break;
        case 3:
          //has the RVR execute findOut360() to turn right until path is clear
          findOut360(true, speed, deg);
        break;
        case 4:
          //has the RVR execute findOut360() to turn left until the path is clear
          findOut360(false, speed, deg);
        break;
        case 5:
          //has the RVR execute findOut360() to turn left until the path is clear
          findOut360(false, speed, deg);
        break;
        case 6:
          //has the RVR execute findOut360() to turn right as all sides are blocked
          findOut360(true, speed, deg);
        break;
      }
    }
};