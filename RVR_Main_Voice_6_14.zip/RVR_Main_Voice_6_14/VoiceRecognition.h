// SpheroRVR - Version: Latest 
#include <SpheroRVR.h>
#include "Movement.h"
#include <SoftwareSerial.h>

//#define COMMON_ANODE

int redPin = A3; // R petal on RGB LED module connected to analog pin 3
int greenPin = A4; // G petal on RGB LED module connected to analog pin 4
int bluePin = A5; // B petal on RGB LED module connected to analog pin 5
int d = 500; // delay time in ms (5 ms)
byte com = 0; //reply from voice recognition

SoftwareSerial mySerial(2, 3); // RX on pin 2, TX on pin 3
Movement rover; // creates a rover object of the Movement class

class VoiceRecognition : public Movement
{
  private:
    // function to generate the colors for the LED
    void color(int red, int green, int blue)
    {
      analogWrite(redPin, red);
      analogWrite(greenPin, green);
      analogWrite(bluePin, blue);
    }
  
    void test()
    {
      color(255,255,255); // turn RGB LED on (white)
      delay(d);
      lights.bothHeadlights(lights.yellow);
      delay(d);
      color(255, 0, 0); // turn the RGB LED red
      delay(d);
      lights.bothHeadlights(lights.red);
      delay(d);
      color(0,255, 0); // turn the RGB LED green
      delay(d);
      lights.bothHeadlights(lights.green);
      delay(d);
      color(0, 0, 255); // turn the RGB LED blue
      delay(d);
      lights.bothHeadlights(lights.blue);
      delay(d);
      color(0,0,0); // turn the RGB LED off
      delay(d);
      lights.bothHeadlights(lights.none);
      delay(d);
    }
    
  public:
    //public constants for continuous actions
    //const int STANDARD_RUN = -1, FORWARD = 0, BACKWARD = 1, AVOIDANCE = 2;
    //setup function for VoiceRecognition
    void setup()
    {
      mySerial.begin(9600); // begins the new digital serial monitor (pins 2 and 3)
      pinMode(redPin, OUTPUT); // sets the redPin to be an output
      pinMode(greenPin, OUTPUT); // sets the greenPin to be an output
      pinMode(bluePin, OUTPUT); // sets the bluePin to be an output
      rover.setup(); //sets up the Movement class (and subsequently the Turning and LedControls classes)
      delay(3000);
      mySerial.write(0xAA); // puts the voice recognition module into the "waiting" state
      mySerial.write(0x37); // sets the voice recognition module into "compact" mode
      delay(1000);
      mySerial.write(0xAA); // puts the voice recognition module into the "waiting" state
      mySerial.write(0x21); // imports the voice recognition module group 1 commands
      //mySerial.write(0x22); // imports the voice recognition module group 2 commands
      //mySerial.write(0x23); // imports the voice recognition module group 3 commands
      
      //color(255,255,255); // turn RGB LED on -- white
      delay(d);
      test(); // runs the test() function
      delay(d);
      lights.bothHeadlights(lights.none); // turns off the headlights
    }
    
    //method for serial voice recognition module
    //has the rvr's headlight colors change according to voice commands
    //takes in integer parameters for the speed and time interval to drive forward/backward
    //group 1 commands:
    //red, green, blue, yellow, off
    //group 2 commands:
    //turn left, turn right, turn 180, drive forward, drive backward
    /*void recognize(int speed, int timeMs, int deg)
    {
      while(mySerial.available())
      {
        rvr.resetYaw(); // resets the rvr's heading for driving/turning
        com = mySerial.read();
        switch(com){
          case 0x11:
            //color(255, 0, 0); // turn the RGB LED red
            //delay(d);
            lights.bothHeadlights(lights.red); // turns the headlights red
            delay(d);
          break;
          case 0x12:
            //color(0, 255, 0); // turn the RGB LED green
            //delay(d);
            lights.bothHeadlights(lights.green); // turns the headlights green
            delay(d);
          break;
          case 0x13:
            //color(0, 0, 255); // turn the RGB LED blue
            //delay(d);
            lights.bothHeadlights(lights.blue); // turns the headlights blue
            delay(d);
          break;
          case 0x14:
            //color(255, 255, 255); // turn the RGB LED white
            //delay(d);
            lights.bothHeadlights(lights.yellow); // turns the headlights yellow
            delay(d);
          break;
          case 0x15:
            //color(0,0,0); // turn the RGB LED off
            //delay(d);
            lights.bothHeadlights(lights.none); // turns the headlights off
            delay(d);
          break;
          case 0x21:
            color(255, 0, 0); // turn the RGB LED red
            delay(d);
            lights.bothHeadlights(lights.red); // turns the headlights red
            delay(d);
            turner.turnLeft(); // has the rvr turn left 90 degrees
            delay(d);
          break;
          case 0x22:
            color(0, 255, 0); // turn the RGB LED green
            delay(d);
            lights.bothHeadlights(lights.green);
            delay(d);
            turner.turnRight(); // has the rvr turn right 90 degrees
            delay(d);
          break;
          case 0x23:
            color(0, 0, 255); // turn the RGB LED blue
            delay(d);
            lights.bothHeadlights(lights.blue);
            delay(d);
            turner.turn180(); // has the rvr turn around 180 degrees
            delay(d);
          break;
          case 0x24:
            color(255, 255, 255); // turn the RGB LED white
            delay(d);
            lights.bothHeadlights(lights.yellow);
            delay(d);
            rover.driveForward(speed, timeMs); // has the rvr drive forward for the specified interval
            delay(d);
          break;
          case 0x25:
            color(0,0,0); // turn the RGB LED off
            delay(d);
            lights.bothHeadlights(lights.none); // turns the headlights off
            delay(d);
            rover.driveBackward(speed, timeMs); // has the rvr drive backward for the specified interval
            delay(d);
          break;
          case 0x31:
            color(255, 0, 0); // turn the RGB LED red
            delay(d);
            lights.bothHeadlights(lights.red); // turns the headlights red
            delay(d);
            rover.findOut(speed); // has the rvr execute findOut()
            delay(d);
          break;
          case 0x32:
            color(0, 255, 0); // turn the RGB LED green
            delay(d);
            lights.bothHeadlights(lights.green);
            delay(d);
            rover.findOut360(false, speed, deg); // has the rvr execute findOut360() to the left
            delay(d);
          break;
          case 0x33:
            color(0, 0, 255); // turn the RGB LED blue
            delay(d);
            lights.bothHeadlights(lights.blue);
            delay(d);
            rover.findOut360(true, speed, deg); // has the rvr execute findOut360() to the right
            delay(d);
          break;
          case 0x34:
            color(255, 255, 255); // turn the RGB LED white
            delay(d);
            lights.bothHeadlights(lights.yellow);
            delay(d);
            rover.avoidance(speed, timeMs, deg); // has the rvr execute avoidance()
            delay(d);
          break;
          case 0x35:
            color(0,0,0); // turn the RGB LED off
            delay(d);
            lights.bothHeadlights(lights.none); // turns the headlights off
            delay(d);
            //EMPTY COMMAND-- FILL IN LATER
            //delay(d);
          break;
          default:
            lights.bothHeadlights(lights.purple);
            delay(500);
            lights.bothHeadlights(lights.none);
            delay(d);
          break;
        }
      }
    }*/
    
    bool recognize(int speed, int timeMs, int deg)
    {
      while(mySerial.available())
      {
        rvr.resetYaw(); // resets the rvr's heading for driving/turning
        com = mySerial.read();
        switch(com){
          case 0x11:
            color(255, 0, 0); // turn the RGB LED red
            delay(d);
            lights.bothHeadlights(lights.red); // turns the headlights red
            delay(d);
            turner.turnLeft(); // has the rvr turn left 90 degrees
            delay(d);
          break;
          case 0x12:
            color(0, 255, 0); // turn the RGB LED green
            delay(d);
            lights.bothHeadlights(lights.green);
            delay(d);
            turner.turnRight(); // has the rvr turn right 90 degrees
            delay(d);
          break;
          case 0x13:
            color(0, 0, 255); // turn the RGB LED blue
            delay(d);
            lights.bothHeadlights(lights.blue);
            delay(d);
            rover.driveForward(speed, timeMs); // has the rvr drive forward for the specified interval
            delay(d);
          break;
          case 0x14:
            color(255, 255, 255); // turn the RGB LED white
            delay(d);
            lights.bothHeadlights(lights.yellow);
            delay(d);
            rover.avoidance(speed, timeMs, deg); // has the rvr execute avoidance()
            delay(d);
            return false;
          break;
          case 0x15:
            color(0,0,0); // turn the RGB LED off
            delay(d);
            lights.bothHeadlights(lights.none); // turns the headlights off
            delay(d);
          break;
        }
      }
      return true;
    }
};